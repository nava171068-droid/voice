Mic Clips - floating mic button that records your voice into short clips.

Build with GitHub Actions:
  1. Put this zip in the ROOT of your GitHub repo.
  2. Put build-apk.yml at  .github/workflows/build-apk.yml
  3. Push. Actions unzips the project and builds the APK -> download it from the run's "Artifacts".

Clips are saved (WAV, 16 kHz mono) in:  Android/data/com.grotesque.micclips/files/clips/

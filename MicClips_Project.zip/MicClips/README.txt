Mic Clips - floating mic button that records your voice into short clips.

Build with GitHub Actions:
  1. Put this zip in the ROOT of your GitHub repo.
  2. Put build-apk.yml at  .github/workflows/build-apk.yml
  3. Push. Actions unzips the project and builds the APK -> download it from the run's "Artifacts".

Clips are saved (WAV, 16 kHz mono) in:  Android/data/com.grotesque.micclips/files/clips/

--- Minecraft link (Revervox addon v1.0.4+) ---
1. Start the app (Start button). Enter your in-game name in the app.
2. Minecraft: Settings > General > turn OFF "Require Encrypted WebSockets".
3. In the world (cheats on) type:  /connect 127.0.0.1:19131   (PC: tick "Allow LAN", use the phone's Wi-Fi IP)
4. Your voice clips become Revervox "lines"; when Revervox speaks one, the phone plays the real clip.

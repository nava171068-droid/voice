package com.grotesque.micclips;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Random;

public class MainActivity extends Activity {
    private TextView status, levelTv, clipsTv, thrTv;
    private SeekBar seek;
    private MediaPlayer player;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("mic", MODE_PRIVATE);
        MicService.threshold = sp.getInt("thr", 1200);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#1E1E1E"));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(28), dp(20), dp(28));
        sv.addView(col);

        col.addView(text("Mic Clips", 26, Color.WHITE));
        col.addView(text("ปุ่มไมค์ลอยเหมือนในเกม อัดเสียงของคุณเป็นคลิปสั้นๆ อัตโนมัติ\nFloating mic button that records your voice into short clips.", 14, Color.parseColor("#B0B0B0")));

        status = text("", 14, Color.parseColor("#FFE591"));
        col.addView(status);

        col.addView(button("1. อนุญาตไมโครโฟน / Allow microphone", v -> {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}, 1);
            } else if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            }
        }));
        col.addView(button("2. อนุญาตปุ่มลอยทับแอปอื่น / Allow floating button", v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));
        col.addView(button("3. เริ่ม / Start", v -> start()));
        col.addView(button("หยุด / Stop", v -> stopService(new Intent(this, MicService.class))));

        col.addView(text("ความไวไมค์ / Sensitivity", 16, Color.WHITE));
        thrTv = text("", 13, Color.parseColor("#B0B0B0"));
        col.addView(thrTv);
        seek = new SeekBar(this);
        seek.setMax(5700);
        seek.setProgress(MicService.threshold - 300);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                MicService.threshold = p + 300;
                getSharedPreferences("mic", MODE_PRIVATE).edit().putInt("thr", p + 300).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        col.addView(seek);
        levelTv = text("", 14, Color.WHITE);
        col.addView(levelTv);

        col.addView(text("คลิปที่อัดไว้ / Saved clips", 16, Color.WHITE));
        clipsTv = text("", 14, Color.parseColor("#B0B0B0"));
        col.addView(clipsTv);
        col.addView(button("เล่นคลิปสุ่ม / Play random clip", v -> playRandom()));
        col.addView(button("ลบคลิปทั้งหมด / Delete all clips", v -> {
            ClipStore.deleteAll(this);
            Toast.makeText(this, "ลบแล้ว / Deleted", Toast.LENGTH_SHORT).show();
        }));
        col.addView(button("รีเซ็ตตำแหน่งปุ่ม / Reset button position", v -> {
            getSharedPreferences("mic", MODE_PRIVATE).edit().remove("x").remove("y").apply();
            Toast.makeText(this, "เริ่มใหม่แล้วจะอยู่ตำแหน่งเดิม / Applies on next start", Toast.LENGTH_SHORT).show();
        }));
        col.addView(text("ปุ่มลอย: แตะ = ปิด/เปิดไมค์, ลาก = ย้ายตำแหน่ง, ปุ่มกดค้างสีเข้ม = กำลังจับเสียงพูด\nFloating button: tap = mute/unmute, drag = move, pressed look = voice detected.", 12, Color.parseColor("#909090")));
        setContentView(sv);
    }

    private boolean hasMic() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void start() {
        if (!hasMic()) { Toast.makeText(this, "ต้องอนุญาตไมโครโฟนก่อน / Allow microphone first", Toast.LENGTH_LONG).show(); return; }
        if (!hasOverlay()) { Toast.makeText(this, "ต้องอนุญาตปุ่มลอยก่อน / Allow the floating button first", Toast.LENGTH_LONG).show(); return; }
        Intent i = new Intent(this, MicService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void playRandom() {
        File[] fs = ClipStore.list(this);
        if (fs.length == 0) { Toast.makeText(this, "ยังไม่มีคลิป / No clips yet", Toast.LENGTH_SHORT).show(); return; }
        File f = fs[rnd.nextInt(fs.length)];
        try {
            if (player != null) player.release();
            player = new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.prepare();
            player.start();
        } catch (Exception e) {
            Toast.makeText(this, "เล่นไม่ได้ / Cannot play", Toast.LENGTH_SHORT).show();
        }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            status.setText("ไมค์ / Mic: " + (hasMic() ? "OK" : "✗") + "   ปุ่มลอย / Overlay: " + (hasOverlay() ? "OK" : "✗")
                    + "\nสถานะ / Status: " + (MicService.running ? "กำลังทำงาน / Running" : "หยุด / Stopped"));
            thrTv.setText("เกณฑ์ / Threshold: " + MicService.threshold + "  (ต่ำ = ไวขึ้น / lower = more sensitive)");
            levelTv.setText("ระดับเสียงตอนนี้ / Live level: " + MicService.level);
            File[] fs = ClipStore.list(MainActivity.this);
            double secs = 0;
            for (File f : fs) secs += ClipStore.seconds(f);
            clipsTv.setText(fs.length + " / " + ClipStore.MAX_CLIPS + " คลิป / clips, " + String.format("%.0f", secs) + " s");
            h.postDelayed(this, 300);
        }
    };

    @Override protected void onResume() { super.onResume(); h.post(tick); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }
    @Override protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}

package com.grotesque.micclips;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.Random;

public class MainActivity extends Activity {
    private TextView status, levelTv, clipsTv, thrTv, linkTv;
    private SeekBar seek;
    private MediaPlayer player;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    private TextView text(String s, int sp, int color) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        t.setPadding(0, dp(6), 0, dp(6));
        return t;
    }

    private Button button(String s, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setOnClickListener(l);
        return b;
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("mic", MODE_PRIVATE);
        MicService.threshold = sp.getInt("thr", 1200);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Color.parseColor("#1E1E1E"));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(28), dp(20), dp(28));
        sv.addView(col);

        col.addView(text("Mic Clips", 26, Color.WHITE));
        col.addView(text("Floating mic button that records your voice into short clips.", 14, Color.parseColor("#B0B0B0")));

        status = text("", 14, Color.parseColor("#FFE591"));
        col.addView(status);

        col.addView(button("1. Allow microphone", v -> {
            if (Build.VERSION.SDK_INT >= 33) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS}, 1);
            } else if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 1);
            }
        }));
        col.addView(button("2. Allow floating button", v -> {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));
        col.addView(button("3. Start", v -> start()));
        col.addView(button("Stop", v -> stopService(new Intent(this, MicService.class))));

        col.addView(text("Minecraft link", 16, Color.WHITE));
        col.addView(text("In game type:  /connect 127.0.0.1:" + WsBridge.PORT + "\n(Turn OFF Require Encrypted WebSockets in Settings > General)", 12, Color.parseColor("#909090")));
        EditText nameEt = new EditText(this);
        nameEt.setHint("In-game name");
        nameEt.setHintTextColor(Color.parseColor("#707070"));
        nameEt.setTextColor(Color.WHITE);
        nameEt.setSingleLine(true);
        nameEt.setText(sp.getString("pname", ""));
        nameEt.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) {
                getSharedPreferences("mic", MODE_PRIVATE).edit().putString("pname", e.toString().trim()).apply();
            }
        });
        col.addView(nameEt);
        CheckBox lanCb = new CheckBox(this);
        lanCb.setText("Allow LAN connections (e.g. PC) - press Start again after changing");
        lanCb.setTextColor(Color.parseColor("#B0B0B0"));
        lanCb.setChecked(sp.getBoolean("lan", false));
        lanCb.setOnCheckedChangeListener((v, on) -> getSharedPreferences("mic", MODE_PRIVATE).edit().putBoolean("lan", on).apply());
        col.addView(lanCb);

        col.addView(text("Sensitivity", 16, Color.WHITE));
        thrTv = text("", 13, Color.parseColor("#B0B0B0"));
        col.addView(thrTv);
        seek = new SeekBar(this);
        seek.setMax(5700);
        seek.setProgress(MicService.threshold - 300);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean user) {
                MicService.threshold = p + 300;
                getSharedPreferences("mic", MODE_PRIVATE).edit().putInt("thr", p + 300).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
        col.addView(seek);
        levelTv = text("", 14, Color.WHITE);
        col.addView(levelTv);

        col.addView(text("Game link check", 16, Color.WHITE));
        linkTv = text("", 12, Color.parseColor("#B0B0B0"));
        col.addView(linkTv);
        col.addView(button("Send test message to game", v -> {
            WsBridge w = WsBridge.current;
            if (w == null || !WsBridge.connected) { Toast.makeText(this, "Not connected to Minecraft", Toast.LENGTH_SHORT).show(); return; }
            w.command("say [MicClips] link OK");
        }));

        col.addView(text("Saved clips", 16, Color.WHITE));
        clipsTv = text("", 14, Color.parseColor("#B0B0B0"));
        col.addView(clipsTv);
        final String[] fxNames = {"Off", "Creepy (low + echo)", "Bat (high)"};
        final Button fxBtn = button("", null);
        fxBtn.setText("Revervox voice effect: " + fxNames[sp.getInt("fx", 0) % 3]);
        fxBtn.setOnClickListener(v -> {
            int n = (getSharedPreferences("mic", MODE_PRIVATE).getInt("fx", 0) + 1) % 3;
            getSharedPreferences("mic", MODE_PRIVATE).edit().putInt("fx", n).apply();
            fxBtn.setText("Revervox voice effect: " + fxNames[n]);
        });
        col.addView(fxBtn);
        col.addView(button("Play random clip", v -> playRandom()));
        col.addView(button("Delete all clips", v -> {
            ClipStore.deleteAll(this);
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show();
        }));
        col.addView(button("Reset button position", v -> {
            getSharedPreferences("mic", MODE_PRIVATE).edit().remove("x").remove("y").apply();
            Toast.makeText(this, "Applies on next start", Toast.LENGTH_SHORT).show();
        }));
        col.addView(text("Floating button: tap = mute/unmute, drag = move, pressed look = voice detected.", 12, Color.parseColor("#909090")));
        col.addView(button("License / ลิขสิทธิ์", v -> showLicense()));
        col.addView(text("(c) 2026 SappyLotus1831. Personal use and study only. Sharing or distributing needs permission from SappyLotus1831 first.", 12, Color.parseColor("#909090")));
        setContentView(sv);
    }

    private boolean hasMic() {
        return Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private boolean hasOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void start() {
        if (!hasMic()) { Toast.makeText(this, "Allow microphone first", Toast.LENGTH_LONG).show(); return; }
        if (!hasOverlay()) { Toast.makeText(this, "Allow the floating button first", Toast.LENGTH_LONG).show(); return; }
        Intent i = new Intent(this, MicService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    private void showLicense() {
        String t;
        try (java.io.InputStream in = getAssets().open("LICENSE.txt")) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] b = new byte[4096];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            t = new String(bo.toByteArray(), java.nio.charset.StandardCharsets.UTF_8);
        } catch (Exception e) {
            t = "(c) 2026 SappyLotus1831. Personal use and study only. Distribution needs permission from SappyLotus1831.";
        }
        new android.app.AlertDialog.Builder(this).setTitle("License").setMessage(t).setPositiveButton("OK", null).show();
    }

    private void playRandom() {
        File[] fs = ClipStore.list(this);
        if (fs.length == 0) { Toast.makeText(this, "No clips yet", Toast.LENGTH_SHORT).show(); return; }
        File f = fs[rnd.nextInt(fs.length)];
        try {
            if (player != null) player.release();
            player = new MediaPlayer();
            player.setDataSource(f.getAbsolutePath());
            player.prepare();
            player.start();
        } catch (Exception e) {
            Toast.makeText(this, "Cannot play", Toast.LENGTH_SHORT).show();
        }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            status.setText("Mic: " + (hasMic() ? "OK" : "✗") + "   Overlay: " + (hasOverlay() ? "OK" : "✗")
                    + "   Minecraft: " + (WsBridge.connected ? "connected" : "waiting") + "\nStatus: " + (MicService.running ? "Running" : "Stopped"));
            thrTv.setText("Threshold: " + MicService.threshold + "  (lower = more sensitive)");
            levelTv.setText("Live level: " + MicService.level);
            linkTv.setText("Last sent: " + WsBridge.lastSent + "\nGame reply: " + WsBridge.lastReply);
            File[] fs = ClipStore.list(MainActivity.this);
            double secs = 0;
            for (File f : fs) secs += ClipStore.seconds(f);
            clipsTv.setText(fs.length + " / " + ClipStore.MAX_CLIPS + " clips, " + String.format("%.0f", secs) + " s");
            h.postDelayed(this, 300);
        }
    };

    @Override protected void onResume() { super.onResume(); h.post(tick); }
    @Override protected void onPause() { super.onPause(); h.removeCallbacks(tick); }
    @Override protected void onDestroy() {
        if (player != null) { player.release(); player = null; }
        super.onDestroy();
    }
}

package com.grotesque.micclips;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tiny WebSocket server so Minecraft Bedrock can attach with:  /connect <ip>:19131
 * App -> game : commands (scriptevent revervox:...)
 * Game -> app : PlayerMessage events (we look for "RVXCLIP:clip_123.wav")
 */
public final class WsBridge {
    public interface Listener { void onClipRequested(String fileName); }

    public static final int PORT = 19131;
    public static volatile boolean connected = false;
    public static volatile String lastSent = "-";
    public static volatile String lastReply = "-";
    public static volatile WsBridge current;

    private static final String GUID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    private static final Pattern CLIP = Pattern.compile("RVXCLIP:(clip_\\d+\\.wav)");

    private final Listener listener;
    private final boolean lan;
    private final ExecutorService sender = Executors.newSingleThreadExecutor();
    private volatile boolean stop = false;
    private volatile ServerSocket server;
    private volatile Socket client;
    private volatile OutputStream out;
    private Thread thread;

    public WsBridge(boolean allowLan, Listener l) { this.lan = allowLan; this.listener = l; }

    public void start() {
        current = this;
        thread = new Thread(this::run, "ws-bridge");
        thread.start();
    }

    public void shutdown() {
        if (current == this) current = null;
        stop = true;
        connected = false;
        try { if (client != null) client.close(); } catch (IOException ignored) {}
        try { if (server != null) server.close(); } catch (IOException ignored) {}
        sender.shutdownNow();
    }

    /** Run a game command (without the leading slash). Safe to call from any thread. */
    public void command(String line) {
        if (!connected) return;
        lastSent = line;
        sender.execute(() -> {
            try {
                JSONObject origin = new JSONObject().put("type", "player");
                JSONObject body = new JSONObject().put("origin", origin).put("commandLine", line).put("version", 1);
                JSONObject header = new JSONObject()
                        .put("requestId", UUID.randomUUID().toString())
                        .put("messagePurpose", "commandRequest")
                        .put("version", 1)
                        .put("messageType", "commandRequest");
                sendText(new JSONObject().put("body", body).put("header", header).toString());
            } catch (Exception ignored) {}
        });
    }

    private void run() {
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(InetAddress.getByName(lan ? "0.0.0.0" : "127.0.0.1"), PORT));
            while (!stop) {
                Socket s = server.accept();
                try { serve(s); } catch (Exception ignored) {}
                connected = false;
                out = null;
                try { s.close(); } catch (IOException ignored) {}
            }
        } catch (Exception ignored) {
        } finally {
            connected = false;
        }
    }

    private void serve(Socket s) throws Exception {
        client = s;
        s.setTcpNoDelay(true);
        DataInputStream in = new DataInputStream(new BufferedInputStream(s.getInputStream()));
        OutputStream os = s.getOutputStream();

        // --- HTTP upgrade handshake ---
        String key = null;
        while (true) {
            String line = readLine(in);
            if (line == null) return;
            if (line.isEmpty()) break;
            int c = line.indexOf(':');
            if (c > 0 && line.substring(0, c).trim().equalsIgnoreCase("Sec-WebSocket-Key")) key = line.substring(c + 1).trim();
        }
        if (key == null) return;
        byte[] sha = MessageDigest.getInstance("SHA-1").digest((key + GUID).getBytes(StandardCharsets.US_ASCII));
        String accept = android.util.Base64.encodeToString(sha, android.util.Base64.NO_WRAP);
        os.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: " + accept + "\r\n\r\n")
                .getBytes(StandardCharsets.US_ASCII));
        os.flush();
        out = os;
        connected = true;

        // subscribe to chat-like messages so the game can send us "RVXCLIP:..."
        JSONObject header = new JSONObject().put("requestId", UUID.randomUUID().toString())
                .put("messagePurpose", "subscribe").put("version", 1).put("messageType", "commandRequest");
        JSONObject body = new JSONObject().put("eventName", "PlayerMessage");
        sendText(new JSONObject().put("body", body).put("header", header).toString());

        // --- frame loop ---
        StringBuilder text = new StringBuilder();
        while (!stop) {
            int b0 = in.read();
            int b1 = in.read();
            if (b0 < 0 || b1 < 0) return;
            int op = b0 & 0x0f;
            boolean fin = (b0 & 0x80) != 0;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7f;
            if (len == 126) len = in.readUnsignedShort();
            else if (len == 127) len = in.readLong();
            if (len < 0 || len > (1 << 20)) return;
            byte[] mask = new byte[4];
            if (masked) in.readFully(mask);
            byte[] data = new byte[(int) len];
            in.readFully(data);
            if (masked) for (int i = 0; i < data.length; i++) data[i] ^= mask[i & 3];

            if (op == 0 || op == 1) {
                text.append(new String(data, StandardCharsets.UTF_8));
                if (fin) { handleMessage(text.toString()); text.setLength(0); }
            } else if (op == 8) {
                return;
            } else if (op == 9) {
                sendFrame(0x8A, data);
            }
        }
    }

    private volatile String lastClip = "";
    private volatile long lastClipAt = 0;

    private void handleMessage(String json) {
        try {
            JSONObject o = new JSONObject(json);
            JSONObject h = o.optJSONObject("header");
            if (h == null) return;
            JSONObject b = o.optJSONObject("body");
            if (b == null) return;
            if ("commandResponse".equals(h.optString("messagePurpose"))) {
                lastReply = "code " + b.optInt("statusCode", 0) + " " + b.optString("statusMessage", "");
                return;
            }
            if (!"event".equals(h.optString("messagePurpose"))) return;
            // look anywhere in the event body (message / parameters) for the strict clip name
            Matcher m = CLIP.matcher(b.toString());
            if (m.find() && listener != null) {
                String f = m.group(1); // strict filename only
                long t = System.currentTimeMillis();
                if (f.equals(lastClip) && t - lastClipAt < 2000) return; // tell + say duplicates
                lastClip = f; lastClipAt = t;
                listener.onClipRequested(f);
            }
        } catch (Exception ignored) {}
    }

    private void sendText(String s) throws IOException { sendFrame(0x81, s.getBytes(StandardCharsets.UTF_8)); }

    private synchronized void sendFrame(int b0, byte[] payload) throws IOException {
        OutputStream os = out;
        if (os == null) return;
        os.write(b0);
        if (payload.length < 126) {
            os.write(payload.length);
        } else if (payload.length < 65536) {
            os.write(126); os.write(payload.length >> 8); os.write(payload.length & 0xff);
        } else {
            os.write(127);
            for (int i = 7; i >= 0; i--) os.write((int) (((long) payload.length >> (8 * i)) & 0xff));
        }
        os.write(payload);
        os.flush();
    }

    private static String readLine(DataInputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 8192) return null;
        }
        return c < 0 && sb.length() == 0 ? null : sb.toString();
    }
}

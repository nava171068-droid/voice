package com.grotesque.micclips;

import android.content.Context;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.Comparator;

/** Saves/reads the recorded voice clips (16 kHz mono 16-bit WAV). */
public final class ClipStore {
    public static final int RATE = 16000;
    public static final int MAX_CLIPS = 200;

    private ClipStore() {}

    public static File dir(Context c) {
        File base = c.getExternalFilesDir(null);
        if (base == null) base = c.getFilesDir();
        File d = new File(base, "clips");
        if (!d.exists()) d.mkdirs();
        return d;
    }

    public static File[] list(Context c) {
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".wav"));
        if (fs == null) return new File[0];
        Arrays.sort(fs, Comparator.comparingLong(File::lastModified));
        return fs;
    }

    public static double seconds(File f) {
        return Math.max(0, f.length() - 44) / 2.0 / RATE;
    }

    public static File save(Context c, short[] pcm) throws IOException {
        File f = new File(dir(c), "clip_" + System.currentTimeMillis() + ".wav");
        int dataLen = pcm.length * 2;
        ByteBuffer bb = ByteBuffer.allocate(44 + dataLen).order(ByteOrder.LITTLE_ENDIAN);
        bb.put("RIFF".getBytes("US-ASCII"));
        bb.putInt(36 + dataLen);
        bb.put("WAVE".getBytes("US-ASCII"));
        bb.put("fmt ".getBytes("US-ASCII"));
        bb.putInt(16);
        bb.putShort((short) 1);
        bb.putShort((short) 1);
        bb.putInt(RATE);
        bb.putInt(RATE * 2);
        bb.putShort((short) 2);
        bb.putShort((short) 16);
        bb.put("data".getBytes("US-ASCII"));
        bb.putInt(dataLen);
        for (short s : pcm) bb.putShort(s);
        try (FileOutputStream fos = new FileOutputStream(f)) {
            fos.write(bb.array());
        }
        File[] all = list(c);
        for (int i = 0; i < all.length - MAX_CLIPS; i++) all[i].delete(); // drop the oldest
        return f;
    }

    public static void deleteAll(Context c) {
        for (File f : list(c)) f.delete();
    }
}

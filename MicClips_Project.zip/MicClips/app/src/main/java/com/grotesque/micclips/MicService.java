package com.grotesque.micclips;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * Foreground service: floating draggable mic button + voice recorder.
 * Speech is cut into clips automatically (voice-activity detection), like the
 * recording add-on used with Simple Voice Chat.
 */
public class MicService extends Service {
    public static final String ACTION_STOP = "com.grotesque.micclips.STOP";
    private static final String CHANNEL = "mic_clips";
    private static final int NOTIF_ID = 7;

    public static volatile boolean running = false;
    public static volatile int threshold = 1200; // RMS needed to count as speech
    public static volatile int level = 0;        // live mic level for the settings screen

    private WindowManager wm;
    private FrameLayout root;
    private ImageView bgView, micView;
    private WindowManager.LayoutParams lp;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private volatile boolean muted = false;
    private volatile boolean speaking = false;
    private boolean touching = false;
    private volatile boolean stopFlag = false;
    private Thread recThread;

    private Drawable dBtn, dBtnPressed, dMic, dMicOff;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;
        running = true;
        threshold = getSharedPreferences("mic", MODE_PRIVATE).getInt("thr", 1200);
        startInForeground();
        if (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this)) buildOverlay();
        startRecorder();
        return START_NOT_STICKY;
    }

    private void startInForeground() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Mic Clips", NotificationManager.IMPORTANCE_LOW));
            nb = new Notification.Builder(this, CHANNEL);
        } else {
            nb = new Notification.Builder(this);
        }
        Intent stop = new Intent(this, MicService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        nb.setSmallIcon(R.drawable.ic_stat_mic)
          .setContentTitle("Mic Clips")
          .setContentText("กำลังฟังเสียงของคุณ / Listening to your voice")
          .setOngoing(true)
          .addAction(new Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat_mic), "Stop", pi).build());
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    // ---------- floating button ----------
    private Drawable crisp(int resId) {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inScaled = false;
        Bitmap bmp = BitmapFactory.decodeResource(getResources(), resId, o);
        BitmapDrawable d = new BitmapDrawable(getResources(), bmp);
        d.setFilterBitmap(false); // keep the pixel-art look
        return d;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void buildOverlay() {
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        dBtn = crisp(R.drawable.button);
        dBtnPressed = crisp(R.drawable.button_pressed);
        dMic = crisp(R.drawable.microphone);
        dMicOff = crisp(R.drawable.microphone_off);

        final int size = dp(52);
        root = new FrameLayout(this);
        bgView = new ImageView(this);
        bgView.setScaleType(ImageView.ScaleType.FIT_XY);
        root.addView(bgView, new FrameLayout.LayoutParams(size, size));
        micView = new ImageView(this);
        micView.setScaleType(ImageView.ScaleType.FIT_XY);
        int ic = size * 16 / 22;
        FrameLayout.LayoutParams ml = new FrameLayout.LayoutParams(ic, ic, Gravity.CENTER);
        root.addView(micView, ml);
        refreshUi();

        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        lp = new WindowManager.LayoutParams(size, size, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        SharedPreferences sp = getSharedPreferences("mic", MODE_PRIVATE);
        int sw = getResources().getDisplayMetrics().widthPixels;
        lp.x = sp.getInt("x", sw - size - dp(16));
        lp.y = sp.getInt("y", dp(200));

        final int slop = ViewConfiguration.get(this).getScaledTouchSlop();
        root.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; boolean dragging;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = lp.x; startY = lp.y; dragging = false;
                        touching = true; refreshUi();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                        if (!dragging && (Math.abs(dx) > slop || Math.abs(dy) > slop)) dragging = true;
                        if (dragging) {
                            lp.x = startX + (int) dx;
                            lp.y = startY + (int) dy;
                            try { wm.updateViewLayout(root, lp); } catch (Exception ignored) {}
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        touching = false;
                        if (dragging) {
                            getSharedPreferences("mic", MODE_PRIVATE).edit().putInt("x", lp.x).putInt("y", lp.y).apply();
                        } else if (e.getAction() == MotionEvent.ACTION_UP) {
                            muted = !muted; // tap = mute / unmute
                            if (muted) speaking = false;
                        }
                        refreshUi();
                        return true;
                }
                return false;
            }
        });
        try { wm.addView(root, lp); } catch (Exception ex) { root = null; }
    }

    private void refreshUi() {
        if (bgView == null) return;
        bgView.setImageDrawable((touching || speaking) ? dBtnPressed : dBtn);
        micView.setImageDrawable(muted ? dMicOff : dMic);
    }

    private void setSpeaking(boolean s) {
        if (speaking == s) return;
        speaking = s;
        ui.post(this::refreshUi);
    }

    // ---------- recorder with voice-activity detection ----------
    private void startRecorder() {
        stopFlag = false;
        recThread = new Thread(this::recordLoop, "mic-recorder");
        recThread.start();
    }

    private void recordLoop() {
        final int rate = ClipStore.RATE;
        final int frame = rate / 50; // 20 ms
        int minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        AudioRecord ar = null;
        try {
            ar = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, Math.max(minBuf, frame * 2 * 10));
            if (ar.getState() != AudioRecord.STATE_INITIALIZED) {
                ui.post(this::stopSelf);
                return;
            }
            ar.startRecording();
            short[] buf = new short[frame];
            ArrayDeque<short[]> pre = new ArrayDeque<>();
            ArrayList<short[]> cur = new ArrayList<>();
            boolean inSeg = false;
            int silent = 0;
            while (!stopFlag) {
                int n = ar.read(buf, 0, frame);
                if (n <= 0) continue;
                double sum = 0;
                for (int i = 0; i < n; i++) sum += (double) buf[i] * buf[i];
                int rms = (int) Math.sqrt(sum / n);
                level = rms;
                if (muted) { inSeg = false; cur.clear(); pre.clear(); silent = 0; continue; }
                boolean loud = rms > threshold;
                short[] copy = Arrays.copyOf(buf, n);
                if (!inSeg) {
                    pre.addLast(copy);
                    if (pre.size() > 15) pre.removeFirst();   // 300 ms pre-roll
                    if (loud) {
                        inSeg = true; silent = 0;
                        cur.addAll(pre); pre.clear();
                        setSpeaking(true);
                    }
                } else {
                    cur.add(copy);
                    if (loud) silent = 0; else silent++;
                    if (silent >= 35 || cur.size() >= 600) { // 700 ms of silence, or 12 s max
                        int keep = cur.size() - Math.max(0, silent - 10);
                        saveClip(cur, keep);
                        cur.clear(); inSeg = false; silent = 0;
                        setSpeaking(false);
                    }
                }
            }
        } catch (Throwable t) {
            // recording stopped unexpectedly
        } finally {
            if (ar != null) {
                try { ar.stop(); } catch (Throwable ignored) {}
                ar.release();
            }
            level = 0;
        }
    }

    private void saveClip(ArrayList<short[]> frames, int keepFrames) {
        if (keepFrames < 20) return; // shorter than 0.4 s: noise, ignore
        int total = 0;
        for (int i = 0; i < keepFrames; i++) total += frames.get(i).length;
        short[] pcm = new short[total];
        int pos = 0;
        for (int i = 0; i < keepFrames; i++) {
            short[] f = frames.get(i);
            System.arraycopy(f, 0, pcm, pos, f.length);
            pos += f.length;
        }
        try { ClipStore.save(this, pcm); } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        running = false;
        stopFlag = true;
        if (recThread != null) {
            try { recThread.join(800); } catch (InterruptedException ignored) {}
        }
        if (root != null && wm != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            root = null;
        }
        super.onDestroy();
    }
}
